package org.apache.flume.interceptor;

import com.google.common.base.Preconditions;
import org.apache.commons.lang.StringUtils;
import org.apache.flume.Context;
import org.apache.flume.conf.ComponentConfiguration;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * User: pkatsev
 * Date: 5/6/13
 * Serializer that converts the passed in value into milliseconds using the
 * specified formatting pattern
 */
public class RegexExtractorInterceptorMillisSerializerNonJoda implements RegexExtractorInterceptorSerializer {

    private SimpleDateFormat formatter;

    @Override
    public void configure(final Context context) {
        final String pattern = context.getString("pattern");
        Preconditions.checkArgument(!StringUtils.isEmpty(pattern),
                "Must configure with a valid pattern");
        formatter = new SimpleDateFormat(pattern);
    }

    @Override
    public String serialize(final String value) {
        try {
            final Date date = formatter.parse(value);
            return Long.toString(date.getTime());
        } catch (final ParseException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void configure(ComponentConfiguration conf) {
        // NO-OP...
    }
}