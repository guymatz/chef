This is an empty README to make Berkshelf happy.
