## v0.7.0:

Initial import from Heavywater upstream: https://github.com/heavywater/chef-jenkins
