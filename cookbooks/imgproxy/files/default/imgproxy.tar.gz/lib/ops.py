from PIL import Image
from collections import namedtuple

Dim = namedtuple('Dim', 'w h')
Point = namedtuple('Point', 'x y')

class OperationError(Exception):
    pass


class Operations(object):
    rotate_funcs = ('FLIP_LEFT_RIGHT', 'FLIP_TOP_BOTTOM', 'ROTATE_90', 'ROTATE_180', 'ROTATE_270')
    size = None
    _anchor = None

    def __init__(self, images):
        self.images = images
        self.size = Dim(*self.image.size)

    def __call__(self, method, args):
        result = getattr(self, method)(*args)
        self.size = Dim(*self.image.size)
        return result

    @property
    def image(self):
        img = self.images[0]
        return img

    def nop(self):
        return self

    def anchor(self, x, y):
        self._anchor = Point(x, y)
        return self

    def crop(self, w, h):
        size = self.size
        anchor = self._anchor
        if anchor is None:
            anchor = Point(0,0)
        x1, y1 = anchor.x - float(w) / 2, anchor.y - float(h) / 2
        #Top and Left Bounds Checking
        x1 = 0 if x1 < 0 else x1
        y1 = 0 if y1 < 0 else y1

        x2, y2 = x1 + w, y1 + h

        #Bottom and Right bounds checking
        if x2 > size.w:
            x1 -= x2 - size.w
            x2 = size.w
            if x1 < 0:
                xpadding = (w - size.w) / 2
                x1 = -xpadding
                x2 = size.w + xpadding
        if y2 > size.h:
            y1 -= y2 - size.h
            y2 = size.h
            if y1 < 0:
                ypadding = (h - size.h) / 2
                y1 = -ypadding
                y2 = size.h + ypadding

        self.rawcrop(x1, y1, x2, y2)
        return self

    def rawcrop(self, x1, y1, x2, y2):
        self.images = [self.image.crop([int(i) for i in (x1, y1, x2, y2)])]
        return self

    def fit(self, w, h, pad=False):
        """
        Fit is an intelligent combination of crop/anchor/scale which maintains the aspect ratio.
        """
        size = self.size
        factor_op = max if pad is False else min
        anchor = self._anchor

        factor = factor_op(float(w)/size.w, float(h)/size.h)

        self('scale', (size.w*factor, size.h*factor))
        size = self.size
        if anchor is None:
            self('anchor', (size.w/2.0, size.h/2.0))
        self('crop', (w, h))
        return self

    def rotate(self, transform):
        transform = transform.upper()
        if transform in Operations.rotate_funcs:
            self.images = [self.image.transpose(getattr(Image, transform))]

    def scale(self, w, h):
        w, h = float(w), float(h)
        size = self.size
        if not w:
            #Width Autoscale
            w = (h / size.h) * size.w
        if not h:
            #Height Autoscale
            h = (w / size.w) * size.h
        self.images = [self.image.resize((int(w), int(h)), Image.ANTIALIAS)]

        anchor = self._anchor
        if anchor is not None:
            #Scale the anchor as well.
            self('anchor', (w / size.w * anchor.x, h / size.h * anchor.y))
        return self

    def max(self, w, h):
        if self.size.w > w or self.size.h > h:
            self('fit', (min(self.size.w, w), min(self.size.h, h)))
        return self

    def tile(self, w, h):
        num_images = w*h
        if len(self.images) < num_images:
            raise OperationError("Not enough images for tile({0}, {1}). {2} images required, {3} received".format(w, h, w * h, len(self.images)))

        avg_width = sum(Dim(*i.size).w for i in self.images[:num_images]) / num_images
        avg_height = sum(Dim(*i.size).h for i in self.images[:num_images]) / num_images

        new_image = Image.new('RGB', (avg_width * w, avg_height * h))
        for y in xrange(h):
            for x in xrange(w):
                new_image.paste(self.images[y*h + x].resize((avg_width, avg_height)), (x*avg_width, y*avg_height))
        self.images[:num_images] = [new_image]
        return self
