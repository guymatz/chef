from sqlalchemy import create_engine, text
from sqlalchemy.exc import ProgrammingError


class QueryError(Exception):
    pass


class SQLAlchemyEngine(object):
    def __init__(self, connection_string):
        self.engine = create_engine(connection_string, pool_size=10, pool_recycle=300)

    def execute(self, query, **parameters):
        if not query:
            raise QueryError('"query" is required')

        try:
            sql = query + ' LIMIT :limit OFFSET :offset'

            limit = int(parameters.pop('limit', 50))
            offset = int(parameters.pop('offset', 0))

            params = dict(parameters, limit=limit, offset=offset)
            result = self.engine.execute(text(sql), **params)

            fields = result.keys()
            return {
                'query': sql,
                'query_params': parameters,
                'range': {
                    'limit': limit,
                    'offset': offset,
                },
                'fields': fields,
                'result': [dict((fields[i], r[i]) for i in xrange(len(r))) for r in result]
            }
        except ProgrammingError, e:
            raise QueryError(unicode(e))


class DBEnginePool(dict):
    def __init__(self, sources):
        self.sources = sources
        super(DBEnginePool, self).__init__()

    def __getitem__(self, item):
        try:
            return super(DBEnginePool, self).__getitem__(item)
        except KeyError:
            if item not in self.sources:
                raise

        connection_string = self.sources[item]['connection_string']

        scheme, _, _ = connection_string.partition(':')
        driver = SQLAlchemyEngine(connection_string)
        self[item] = driver
        return driver
