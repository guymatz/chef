from pyparsing import *

# Literals
posInt = Word(nums).setParseAction(lambda s,l,t: int(t[0]))

aString = Word(alphanums+'_')#quotedString('string')

boolean = CaselessKeyword("true").setParseAction(lambda s,l,t: True) |\
    CaselessKeyword("false").setParseAction(lambda s,l,t: False)


# Function calls
arg = posInt | boolean | aString
args = Optional(delimitedList(arg))('args')

func = Word(alphas+'_', alphanums+'_')('func')
call = Group(
    func +
    Literal('(').suppress() +
    Group(args) +
    Literal(')').suppress()
)('call')


grammar = Optional(delimitedList(call))


#tests = [
#    'function(3)',
#    'function(true)'
#    'function(3, 5)',
#    'function(3, 5), func2(4)',
#    'function(3, 5), func2(asd3f)',
#]
#
#for t in tests:
#    print grammar.parseString(t)
