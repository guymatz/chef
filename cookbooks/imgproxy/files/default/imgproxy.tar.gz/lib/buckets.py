from collections import namedtuple
import urllib
from urlparse import urlparse


Dim = namedtuple('Dim', 'w h')

BASE_CDN_LOCATION = 'assets.iheart.com'

IMAGE_QUERIES = dict(
    a="""
        SELECT artistimage as image
        FROM amw_artist
        WHERE artistid = :id
    """,
    t="""
        SELECT imagepath as image
        FROM amw_track
            INNER JOIN amw_track_bundle ON (amw_track.trackbundleid = amw_track_bundle.productid)
        WHERE amw_track.productid = :id
    """,
    s="""
        SELECT s.image
        FROM station s
        WHERE s.station_id = :id
    """,
    top="""
        SELECT atb.imagepath as image
        FROM station s
            LEFT JOIN station_cover_product scp ON (s.station_id = scp.station_id)
            LEFT JOIN amw_track t ON scp.cover_product_id = t.productid
            LEFT JOIN amw_track_bundle atb ON t.trackbundleid = atb.productid
        WHERE s.station_id = :id
    """,
)


class BucketException(Exception): pass


class BucketRedirect(object):
    def __init__(self, bucket, name, ops=None):
        self.bucket = bucket
        self.name = name
        self.ops = ops


class Bucket(object):
    def __init__(self, name, config):
        self.name = name
        self.config = config

    def get(self):
        raise NotImplementedError()


class CDNBucket(Bucket):
    IMG_BASE_URL = 'http://static.iheart.com/feat'

    def get(self):
        return '{0}/{1}'.format(self.IMG_BASE_URL, self.name)


class AssetBucket(Bucket):
    #IMG_BASE_URL = 'http://assets.iheart.com'
    IMG_BASE_URL = 'http://'

    def get(self):
        if self.config['IMAGE_SCALER_PROXY_IMAGES'] is True:
            self.IMG_BASE_URL = 'http://img.iheart.com/sca/imscale?w=500&img=http://'

        names = self.name.split(',')
        if len(names) > 1:
            return ['{0}{1}'.format(self.IMG_BASE_URL, name) for name in names]
        return '{0}{1}'.format(self.IMG_BASE_URL, self.name)


class MultiBucket(Bucket):
    def get(self):
        names = self.name.split(',')
        #return [ImageData.from_url(n) for n in names]


class CatalogBucket(Bucket):
    """
    This bucket will always issue a redirect either to the asset or multi bucket.
    """
    KINDS = dict(a='artist', t='track', s='station')

    def get(self):
        kind, id = self.name[:1], self.name[1:]
        if kind not in self.KINDS:
            raise BucketException("No Meta Type '{0}' for Catalog.".format(kind))

        urls = self._query_ingestion(kind, id)
        if urls is None:
            if kind == 's':
                # We have a station URL with no explicit image, let's generate one based on the top 4 tracks.
                urls = self._query_ingestion('top', id)
                if urls is None:
                    return BucketRedirect('asset', 'assets.iheart.com/default/noimage_light_square.png')
                return BucketRedirect('asset',
                    ','.join([urllib.quote(''.join(self._asset_url(u)), '') for u in urls]),
                    ops=[['tile', [2, 2]]]
                )
            else:
                return BucketRedirect('asset', 'assets.iheart.com/default/noimage_light_square.png')

        return BucketRedirect('asset', ''.join(self._asset_url(urls[0])))  # Killing / on path

    def _asset_url(self, url):
        parsed_url = urlparse(url)
        if not parsed_url.netloc:
            # Substitute one in.
            return BASE_CDN_LOCATION+parsed_url.path
        return parsed_url[1:3]

    def _query_ingestion(self, kind, id):
        response = self.config['db_pool']['ingestion'].execute(IMAGE_QUERIES[kind], id=id)
        if not len(response['result']):
            return None
        images = filter(None, [i['image'] for i in response['result']])
        if images:
            return images
        return None


