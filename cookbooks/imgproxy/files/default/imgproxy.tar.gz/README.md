radioedit-img
=============

The Image Proxy that Radio Edit uses for the UI. Also available as a generic image processing endpoint.

The proxy is based on a few concepts.

1. That there is a bucket associated with the resource which is readable.
1. That you would like to operate on the image in a stream fashion which will modify the resulting resource.

The two primary ways to retrieve an image from the proxy are:

* `/{bucket_name}/{user_ops}/{path:image_name}`
* `/{bucket_name}/{path:image_name}`

Buckets
-------------
Bucket is simple reference built into the application to signify where you want to pull images from.
Currently the buckets are defined in conf.common.

<table>
<tr><td>cdn</td><td>References images located on the static.iheart.com/feat origin.</td></tr>
<tr><td>catalog</td><td>Accepts catalog references and finds the appropriate image to show.</td></tr>
<tr><td>asset</td><td>Much like the cdn bucket, this references images located on assets.iheart.com</td></tr>
</table>

Operations
-------------
Operations are essentially the ad-hoc definition of a stream processor on the image data itself. For example a
URL could look like the following:

```
http://{host}/cdn/fit(250,250)/image/path.png
```

This tell the image server to find `/image/path.png` in the `CDN` bucket and use the `fit()` function on it with the
parameters `250,250`.

Operations can be chained as well:

```
http://{host}/cdn/anchor(50,50),fit(250,250)/image/path.png
```
