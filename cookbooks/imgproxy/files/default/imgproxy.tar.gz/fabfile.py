import os
from fabric.api import task, env
from fabric.colors import red
from deploy.utils import Machine
from deploy.recipe import core, img, varnish

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

OPTIMIZED_JS = 'static/bundle.js'
OPTIMIZED_CSS = {
    'static/css/main.css': 'static/css/bundle.main.css',
    'static/css/browser.css': 'static/css/bundle.browser.css'
}

env.forward_agent = True
env.disable_known_hosts = True
env.reject_unknown_hosts = False
env.no_keys = True
env.abort_on_prompts = True

env.roledefs = {
    'image': Machine(
        username='ec2-user',
        keyfile='deploy/assets/keys/proto',
        hostnames=['ec2-184-72-65-34.compute-1.amazonaws.com']
    ),
}

@task
def recipe():
    if len(env.roles) == 0:
        print(red('** A role must be specified with -R to use Recipe **'))
        print('Current Roles: {0}'.format(env.roledefs.keys()))
#    core()
#    varnish()
#    img()
