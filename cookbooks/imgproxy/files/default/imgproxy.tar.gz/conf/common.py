STRFTIME_RFC1123_DATE_FORMAT = "%a, %d %b %Y %H:%M:%S GMT"
IMAGE_SCALER_PROXY_IMAGES = True

BUCKETS = {
    'cdn': 'lib.buckets.CDNBucket',
    'catalog': 'lib.buckets.CatalogBucket',
    'asset': 'lib.buckets.AssetBucket',
}

DATA_SOURCES = {
    'ingestion': {
        'name': 'Ingestion Database (PostgreSQL)',
        'connection_string': 'postgresql+psycopg2://cms_ro:Wiredsoph@iad-ing101-v260.ihr:5432/thmbamw_ingestion',
    },
}
