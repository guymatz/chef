from fabric.contrib.files import comment
from deploy.utils import FileXfer, UpdateYumRepo, AddPkg, Command, Context, Dir, Defer, \
    Pip, Hup, AddDaemon, Checkout, AddWeb

COMMON_ROOT = '/opt'

core = Context(
    app_name='core',
    supervise_process_dir='/opt/supervisor.d',
    nginx_include_dir='/opt/nginx.d',
)

core.define(
    Command('yum update -y', sudo=True),

    Dir([
        '/opt',  # I do this so I own it after this process.
        '/opt/supervisor.d',
        '/opt/nginx.d',
        '/var/log/supervisor',
    ], sudo=True, take_ownership=True),

    # Install EPEL and Varnish repos.
    UpdateYumRepo('http://download.fedoraproject.org/pub/epel/6/i386/epel-release-6-7.noarch.rpm'),
    UpdateYumRepo('http://repo.varnish-cache.org/redhat/varnish-3.0/el5/noarch/varnish-release-3.0-1.noarch.rpm'),

    # Must modify yum.conf because --disableexcludes doesn't seem to work.
    Defer(comment, '/etc/yum.conf', r'^exclude', use_sudo=True),

    AddPkg(['nginx','collectd','collectd-nginx','zlib-devel','libjpeg','zlib','gcc', 'python-devel',
                        'git','libevent-devel','libevent','zeromq-devel','zeromq']),

    # Things I wish I could install via PIP but CENTOS WOOOO
    AddPkg(['python-setuptools', 'python-ldap', 'python-zmq']),

    Command('easy_install pip', sudo=True),
    Pip(['supervisor','pymongo','python-memcached', 'gunicorn','greenlet', 'statsd']),

    # Transfer file & config templates
    FileXfer('deploy/assets/keep_agent.txt', '/etc/sudoers.d/keep_agent', sudo=True, mode=0440, owner=0, group=0),
    FileXfer('deploy/assets/ssh_conf.txt', '/etc/ssh/ssh_config', sudo=True, mode=644),
    FileXfer('deploy/assets/nginx_proxy_params.txt', '/etc/nginx/proxy_params', sudo=True),
    FileXfer('deploy/assets/supervisor_init.txt', '/etc/init.d/supervisor', sudo=True, mode=755),
    FileXfer('deploy/assets/supervisor.txt', '/etc/supervisord.conf', template=True, sudo=True),
    FileXfer('deploy/assets/nginx.txt', '/etc/nginx/nginx.conf', template=True, sudo=True),

    Command('chkconfig --add supervisor', sudo=True),
    Command('chkconfig --level 345 supervisor on', sudo=True),
    Command('chkconfig --level 345 nginx on', sudo=True),
    Command('chkconfig --level 345 collectd on', sudo=True),

    Hup('nginx'),
    Hup('collectd'),
    Hup('supervisor'),
)

varnish = Context(
    app_name='varnish',
    app_port='8000',  # Assume all backend apps will work here.
    root='/opt',
)
varnish.define(
    AddPkg(['varnish']),
    FileXfer('deploy/assets/varnish_sysconfig.txt', '/etc/sysconfig/varnish', sudo=True),
    FileXfer('deploy/assets/varnish_carbon.py', '{root}/varnish_carbon.py', mode=755),
    FileXfer('deploy/assets/varnish.vcl', '/etc/varnish/default.vcl', template=True, sudo=True),
    Command('chkconfig --add varnish', sudo=True),
    Command('chkconfig --level 345 varnish on', sudo=True),
    Hup('varnish'),
)

img = Context(
    app_name='image',
    root='/opt',
    base_dir='/opt/image',
    supervise_process_dir='/opt/supervisor.d',
    nginx_include_dir='/opt/nginx.d',
)
img.define(
    AddPkg(['python-imaging', 'python-psycopg2']),

    Dir(['{base_dir}'], take_ownership=True, clobber=True),

    Checkout('git@github.com:iheartradio/radioedit-img.git', 'master', '{base_dir}'),

    Command('pip install -r {base_dir}/requirements.txt', sudo=True),

    AddDaemon({
        'environment': 'IMAGE_SERVER_CONF=conf/prod.py',
        'command': '/usr/bin/gunicorn -w 10 -b unix:/tmp/{app_name}.sock -p /var/run/{app_name}.pid server:app',
        'directory': '{base_dir}'
    }),

    AddWeb('{app_name}', '8000')

)
