__author__ = 'trey'

from fabric.api import env, task, require, sudo as run_sudo, run, settings, put
from fabric.colors import green, yellow, magenta, white
from fabric.context_managers import hide
from fabric.contrib.files import upload_template, exists, comment

ASSETS_DIR = './'


#class MachineGroup(object):
#    def __init__(self, environment, machines):
#        self.machines


class Machine(object):
    def __init__(self, keyfile, username, hostnames):
        self.keyfile, self.username, self.hostnames = keyfile, username, hostnames

    def __call__(self):
        env.key_filename = self.keyfile
        env.user = self.username
        env.hosts = self.hostnames
        return self.hostnames


class Context(object):
    def __init__(self, **kwargs):
        self.ctx = kwargs

    def define(self, *instructions):
        self.instructions = instructions

    def chain(self, *instructions):
        for i in instructions:
            self.run(i)

    def run(self, instruction):
        instruction.ctx = self.ctx  # Monkey Patch context in.
        instruction.chain = self.chain
        with settings(hide('stdout'), hide('running')):
            instruction()

    def __call__(self):
        print(green('--- Start Processing of {0}'.format(yellow(self.ctx['app_name'], bold=True))))
        self.chain(*self.instructions)


class InstructionBase(object):
    ctx = None

    def _interpolate(self, string):
        return string.format(**(self.ctx or {}))

    def chain(self, *instructions):
        raise NotImplementedError()

    def __unicode__(self):
        return u'...'

    def __call__(self):
        #:TODO: Turn into a legit LOG command.
        print '{0} Running: {1}'.format(
            white(self.__class__.__name__, bold=True),
            unicode(self)
        )


class Defer(InstructionBase):
    def __init__(self, func, *a, **kw):
        self.func, self.a, self.kw = func, a, kw

    def __call__(self):
        super(Defer, self).__call__()
        self.func(*self.a, **self.kw)


class FileXfer(InstructionBase):
    def __init__(self, source, dest, template=None, sudo=False, mode=None, owner=None, group=None):
        self.source, self.dest, self.template, self.sudo, \
        self.mode, self.owner, self.group = source, dest, template, sudo, mode, owner, group

    def __unicode__(self):
        return u'{source} -> {dest}'.format(**self.__dict__)

    def __call__(self):
        self.source = self._interpolate(self.source)
        self.dest = self._interpolate(self.dest)

        super(FileXfer, self).__call__()

        kwargs = dict(
            use_sudo=self.sudo,
            mirror_local_mode=True
        )
        if self.mode is not None:
            kwargs.update(dict(
                mirror_local_mode=False,
                mode=self.mode
            ))

        if self.template is None:
            kwargs.update(dict(
                local_path=self.source,
                remote_path=self.dest,
            ))
            put(**kwargs)
        else:
            kwargs.update(dict(
                context=self.ctx,
                use_jinja=True,
                template_dir=ASSETS_DIR,
                use_sudo=self.sudo,
                backup=False,
                mirror_local_mode=True
            ))
            upload_template(self.source, self.dest, **kwargs)

        if self.owner is not None:
            run_sudo('chown {0} {1}'.format(self.owner, self.dest))
        if self.group is not None:
            run_sudo('chown :{0} {1}'.format(self.group, self.dest))


class UpdateYumRepo(InstructionBase):
    def __init__(self, repo):
        self.repo = repo

    def __unicode__(self):
        return u'{repo}'.format(**self.__dict__)

    def __call__(self):
        super(UpdateYumRepo, self).__call__()
        #:TODO: Do not blindly do this... check first.
        with settings(warn_only=True):
            run_sudo('rpm -Uvh --nosignature {0}'.format(self.repo))


class AddPkg(InstructionBase):
    def __init__(self, package_list):
        self.package_list = package_list

    def __unicode__(self):
        return u'{package_list}'.format(**self.__dict__)

    def __call__(self):
        super(AddPkg, self).__call__()
        run_sudo('yum install --disableexcludes=kernel* -y {0}'.format(' '.join(self.package_list)))


class Pip(InstructionBase):
    def __init__(self, package_list):
        self.package_list = package_list

    def __unicode__(self):
        return u'{package_list}'.format(**self.__dict__)

    def __call__(self):
        super(Pip, self).__call__()
        run_sudo('pip install {0}'.format(' '.join(self.package_list)))


class Command(InstructionBase):
    def __init__(self, command, sudo=False):
        self.command = command
        self.runner = run if sudo is False else run_sudo

    def __unicode__(self):
        return u'{command}'.format(**self.__dict__)

    def __call__(self):
        self.command = self._interpolate(self.command)

        super(Command, self).__call__()

        if callable(self.command):
            self.command()
        else:
            self.runner(self.command)


class Checkout(InstructionBase):
    def __init__(self, repo, branch, dest):
        self.repo, self.branch, self.dest = repo, branch, dest

    def __unicode__(self):
        return u'{repo} @{branch}'.format(**self.__dict__)

    def __call__(self):
        self.repo = self._interpolate(self.repo)
        self.branch = self._interpolate(self.branch)
        self.dest = self._interpolate(self.dest)

        super(Checkout, self).__call__()

        # If I don't use sudo here, it asks me to authorize the key... WTF
        run_sudo('git clone -b {0} {1} {2}'.format(self.branch, self.repo, self.dest))
        run_sudo('chown -R {0}:{0} {1}'.format(env.user, self.dest))


class Dir(InstructionBase):
    def __init__(self, dirs, sudo=False, take_ownership=True, clobber=False):
        self.dirs = dirs
        self.sudo = sudo
        self.runner = run if sudo is False and take_ownership is False else run_sudo
        self.take_ownership = take_ownership
        self.clobber = clobber

    def __unicode__(self):
        return u'{dirs}'.format(**self.__dict__)

    def _check_and_make(self, dirname):
        if exists(dirname, use_sudo=self.sudo):
            if self.clobber:
                self.runner('rm -rf {0}'.format(dirname))
                self.runner('mkdir -p {0}'.format(dirname))
        else:
            self.runner('mkdir -p {0}'.format(dirname))

    def __call__(self):
        super(Dir, self).__call__()
        for dirname in self.dirs:
            dirname = self._interpolate(dirname)
            self._check_and_make(dirname)
            if self.take_ownership is True:
                run_sudo('chown -R {0}:{0} {1}'.format(env.user, dirname))


class Hup(InstructionBase):
    def __init__(self, service):
        self.service = service

    def __unicode__(self):
        return u'{service}'.format(**self.__dict__)

    def __call__(self):
        super(Hup, self).__call__()
        run_sudo('service {0} stop'.format(self.service))
        run_sudo('service {0} start'.format(self.service))


class AddDaemon(InstructionBase):
    def __init__(self, directives):
        self.directives = directives

    def __call__(self):
        super(AddDaemon, self).__call__()
        self.ctx['directives'] = {}
        for k,v in self.directives.items():
            self.ctx['directives'].update(**{self._interpolate(k): self._interpolate(v)})
        self.chain(
            FileXfer('deploy/assets/supervisor.conf', '{supervise_process_dir}/{app_name}.conf', template=True),
            Hup('supervisor')
        )

class AddWeb(InstructionBase):
    def __init__(self, name, port):
        self.name, self.port = name, port

    def __call__(self):
        self.ctx['app_name'] = self._interpolate(self.name)
        self.ctx['app_port'] = self._interpolate(self.port)

        super(AddWeb, self).__call__()

        self.chain(
            FileXfer('deploy/assets/nginx.conf', '{nginx_include_dir}/{app_name}.conf', template=True),
            Hup('nginx')
        )
