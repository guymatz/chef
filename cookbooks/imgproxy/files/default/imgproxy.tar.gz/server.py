import time
from StringIO import StringIO
from urllib2 import urlopen, URLError, HTTPError
from PIL import Image
from flask import Flask, request, redirect
from lib.db_engine_pool import DBEnginePool
from lib.utils import load_buckets
from lib.lang import grammar
from lib.buckets import BucketException, BucketRedirect
from lib.ops import Operations, OperationError


app = Flask(__name__)
app.config.from_object('conf.common')
try:
    app.config.from_envvar('IMAGE_SERVER_CONF')
except RuntimeError:
    pass # NO OVERRIDES

app.config.update(db_pool=DBEnginePool(sources=app.config['DATA_SOURCES']))

buckets = load_buckets(app.config['BUCKETS'])

def now_time():
    return time.strftime(app.config['STRFTIME_RFC1123_DATE_FORMAT'], time.gmtime())

class ImageData(object):
    def __init__(self, buffer, mimetype):
        self.buffer = buffer
        self.mimetype = mimetype

    @staticmethod
    def from_url(url, timeout=10):
        try:
            remote = urlopen(url, timeout=timeout)
            return ImageData(
                StringIO(remote.read()),  # Must wrap in StringIO since urllib doesn't have seek()
                remote.info().type,
            )

        except HTTPError as e:
            raise BucketException("We were unable to complete this request to "\
                                  "proxy {0} for the following reason: {1} {2}".format(e.filename, e.code, e.msg))
        except URLError as e:
            raise BucketException("We were unable to complete this request to "\
                                  "proxy {0} for the following reason: {1}".format(e.filename, e.reason))

    @staticmethod
    def from_image(image, mimetype):
        obj = ImageData(StringIO(), mimetype)
        image.save(obj.buffer, mimetype.partition('/')[2])
        obj.buffer.seek(0)
        return obj


def serialize_ops(ops):
    stringified = []
    for method, args in ops:
        stringified.append('{0}({1})'.format(method, ','.join([str(arg) for arg in args])))
    return ','.join(stringified)


@app.route("/")
def hello():
    return "Image Proxy is Alive."

@app.errorhandler(404)
def not_found(error):
    return 'This is not a Valid URL', 404

@app.route("/<bucket_name>/<user_ops>/<path:image_name>")
@app.route("/<bucket_name>/<path:image_name>", defaults={'user_ops': ''})
def serve(bucket_name, user_ops, image_name):
    if bucket_name not in buckets:
        return 'No Bucket Named: {0}'.format(bucket_name), 404, None

    user_ops = ','.join(filter(None, [user_ops, request.args.get('ops', '')]))

    #If the grammar support empty strings I wouldn't need to do so many IF tests.
    ops = grammar.parseString(user_ops).asList()

    try:
        bucket = buckets[bucket_name](image_name, app.config)
        urls = bucket.get()
        if isinstance(urls, BucketRedirect):
            if not ops:
                ops = [['nop', []]]
            if urls.ops is not None:
                ops = urls.ops + ops
            response = redirect('/{0}/{1}{2}'.format(urls.bucket, serialize_ops(ops) + '/' if ops else '', urls.name))
            response.headers['Last-Modified'] = now_time()
            response.headers['Cache-Control'] = 'public, max-age=1800'  # 30 minutes
            return response
        if not isinstance(urls, (list, tuple)):
            urls = [urls]
        image_data = [ImageData.from_url(url) for url in urls]
    except BucketException as e:
        return 'Invalid Input: {0}'.format(e.args[0]), 500

    try:
        operations = Operations([Image.open(e.buffer) for e in image_data])

        for method, args in ops:
            operations(method, args)

        mimetype = image_data[0].mimetype
        bytes = StringIO()
        operations.image.save(bytes, format=mimetype.partition('/')[2], quality=95)
        return (
            bytes.getvalue(),
            200,
            {
                'Content-Type': mimetype,
                'Last-Modified': now_time(),
                'Cache-Control': 'public, max-age=604800'  # 30 minutes
            }
        )
    except OperationError as e:
        return 'Invalid Operation: {0}'.format(unicode(e)), 400
    except Exception as e:
        return 'Internal Server Error: {0}'.format(unicode(e)), 500


if __name__ == "__main__":
    app.run(debug=True)
